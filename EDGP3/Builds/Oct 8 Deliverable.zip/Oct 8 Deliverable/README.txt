October 8 Deliverable from Fantastic Four: Alex Foo, Dustin Tsui, Reginald Franklin, Peregrin Garet
Game: Coop Bullet Hell (To be changed later...)

Progress: 

As you can find in the folder, we have 5 main things.  From Alex, we got 1) the PunchKnight concept art (to be used in character selection) and 2) the walking animation.

From Reginald, we got 3) the background art for level 1 and the HUD prototype.

From Dustin, we got 4) one of the enemies that will be seen in the game (cone bullet pattern, fires at player)

From Peregrin, we got 5) the character selection, Xbox controller integration, and swapping roles between Attacking and Defending.

Play the demos to see Dustin and Peregrin's work (a touch of patience is required for Dustin's as the enemy enters the screen and identifies its target)

To use Peregrin's, press any key to get past the loading screen and then use your mouse and the arrow keys to control Players 1 & 2, respectively.  Right now, you can't
select a character for Player 2 with keyboard, use Tab to jump in as PunchKnight.  Once in game, WASD controls Player 1 and Arrow Keys control Player 2.  Press Space to shoot
up to 100 bullets.  Press Z for Player 1 to request/confirm a role swap, if you have an Xbox controller press X to request/confirm a swap.  This functionality isn't fully implemented
but it is most of the way there.