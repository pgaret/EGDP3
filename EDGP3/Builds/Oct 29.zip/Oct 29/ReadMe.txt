Fantastic Four
---------------------

Art: 
--- Sprite sheets for level 1 enemies
--- Sprite sheets for characters 1 & 2 (Dragon Sitter and Punch Knight)
--- In game HUD
--- Character art for Boss 1 (Slime Mage)

Programming: 
--- Boss 1 & 2 mechanics
--- Dragon Sitter has shields (that don't want to go away, but that will change)
--- Put in new HUD
--- Punch Knight and Dragon Sitter are animated
--- Put Bat animation in
---------------------

Playing the game: 

Use mouse to select character for Player 1
Tab and Right Shift to choose between Punch Knight and Dragon Sitter for Player 2)

Player 1: Arrow keys to move, Backspace to shoot.
Player 2: WASD to move, Space to shoot

X to utilize special (wall of bullets from Punch Knight, spawn dragon from Player 2)
Z and Tab (within a second or two of each other) to swap roles