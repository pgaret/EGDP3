﻿using UnityEngine;
using System.Collections;

public class Spin : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		transform.position = new Vector3(0,0,0);
		transform.Rotate(0, 0, Time.deltaTime*10f);
	}
}
