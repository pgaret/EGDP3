Right now, there's a bug in re-loading the scene after death, which causes waves of enemies to overlap.  Thus, the static health build that you can play through without having that occur while still getting all the art and sound.

That is a bug we plan on fixing in the future, for sure.